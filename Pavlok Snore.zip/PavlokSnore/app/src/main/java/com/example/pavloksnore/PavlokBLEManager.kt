package com.example.pavloksnore

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class PavlokBLEManager(
    private val context: Context,
    private val onStateChanged: (BleState) -> Unit,
    private val onEventLogged: (String) -> Unit
) {
    sealed class BleState {
        object Disconnected : BleState()
        object Ready : BleState()
    }

    private val httpClient = OkHttpClient()
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    
    // Cloud API Settings
    private var apiToken: String? = null

    fun setApiToken(token: String) {
        this.apiToken = token
        if (token.isNotEmpty()) {
            onStateChanged(BleState.Ready)
            onEventLogged("Cloud API: Token Updated")
        } else {
            onStateChanged(BleState.Disconnected)
        }
    }

    fun start() {
        if (apiToken.isNullOrEmpty()) {
            onEventLogged("Cloud API: Awaiting Token...")
        } else {
            onStateChanged(BleState.Ready)
            onEventLogged("Cloud API: Ready")
        }
    }

    fun beep(intensity: Int = 80) = triggerCloudStimulus("beep", intensity)
    fun vibrate(intensity: Int = 80) = triggerCloudStimulus("vibe", intensity)
    fun zap(intensity: Int = 50) = triggerCloudStimulus("zap", intensity)

    private fun triggerCloudStimulus(type: String, value: Int) {
        val token = apiToken
        if (token.isNullOrEmpty()) {
            onEventLogged("Error: No API Token set")
            return
        }

        val json = """
            {
              "stimulus": {
                "stimulusType": "$type",
                "stimulusValue": $value,
                "reason": "Snore Detection"
              }
            }
        """.trimIndent()

        val request = Request.Builder()
            .url("https://api.pavlok.com/api/v5/stimulus/send")
            .post(json.toRequestBody(JSON_MEDIA_TYPE))
            .addHeader("Authorization", "Bearer $token")
            .addHeader("Accept", "application/json")
            .build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onEventLogged("Cloud Error: Network failure")
                Log.e("PavlokCloud", "Request failed", e)
            }

            override fun onResponse(call: Call, response: Response) {
                val code = response.code
                if (response.isSuccessful) {
                    onEventLogged("Cloud Success: $type triggered")
                } else {
                    onEventLogged("Cloud Error: Code $code")
                    Log.e("PavlokCloud", "Error response: ${response.body?.string()}")
                }
                response.close()
            }
        })
    }

    fun close() {
        onStateChanged(BleState.Disconnected)
    }
}
