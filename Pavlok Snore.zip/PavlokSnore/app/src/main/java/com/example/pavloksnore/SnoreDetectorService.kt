package com.example.pavloksnore

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.sqrt

data class LogEntry(val timestamp: String, val message: String)

class SnoreDetectorService : Service() {

    private var isRunning = false
    private var bleManager: PavlokBLEManager? = null
    var dataLogger: SnoreDataLogger? = null
        private set

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs

    private val _bleStatus = MutableStateFlow<PavlokBLEManager.BleState>(PavlokBLEManager.BleState.Disconnected)
    val bleStatus: StateFlow<PavlokBLEManager.BleState> = _bleStatus

    private val _totalSnores = MutableStateFlow(0)
    val totalSnores: StateFlow<Int> = _totalSnores

    private val _currentVolume = MutableStateFlow(0f)
    val currentVolume: StateFlow<Float> = _currentVolume

    private val _fileRecordCount = MutableStateFlow(0)
    val fileRecordCount: StateFlow<Int> = _fileRecordCount

    private val _fileSizeText = MutableStateFlow("0 B")
    val fileSizeText: StateFlow<String> = _fileSizeText

    private val _logFilePath = MutableStateFlow("")
    val logFilePath: StateFlow<String> = _logFilePath

    private var stimulusType: String = "beep"
    private var stimulusIntensity: Int = 80

    private val _stimulusType = MutableStateFlow("beep")
    val stimulusTypeFlow: StateFlow<String> = _stimulusType

    private val _stimulusIntensity = MutableStateFlow(80)
    val stimulusIntensityFlow: StateFlow<Int> = _stimulusIntensity

    // User Parameters
    private val VOLUME_THRESHOLD = 0.015f
    private val VOTING_WINDOW_SIZE = 10
    private val VOTING_THRESHOLD = 2
    private val NUDGE_COOLDOWN_MS = 10000L   

    private var lastTriggerTime = 0L
    private val votingHistory = LinkedList<Boolean>()

    inner class ServiceBinder : Binder() {
        fun getService() = this@SnoreDetectorService
    }
    private val binder = ServiceBinder()

    override fun onCreate() {
        super.onCreate()
        dataLogger = SnoreDataLogger(this)
        updateFileStats()

        val prefs = getSharedPreferences("PavlokPrefs", MODE_PRIVATE)
        stimulusType = prefs.getString("stimulus_type", "beep") ?: "beep"
        stimulusIntensity = prefs.getInt("stimulus_intensity", 80)
        _stimulusType.value = stimulusType
        _stimulusIntensity.value = stimulusIntensity

        bleManager = PavlokBLEManager(this, 
            { status -> _bleStatus.value = status },
            { msg -> addLog(msg) }
        )
    }

    private fun addLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val newLogs = _logs.value.toMutableList()
        newLogs.add(0, LogEntry(time, message))
        _logs.value = newLogs
    }

    fun updateFileStats() {
        dataLogger?.let {
            _fileRecordCount.value = it.getRecordCount()
            _fileSizeText.value = it.getFileSizeFormatted()
            _logFilePath.value = it.getLogFilePath()
        }
    }

    fun clearDataLog() {
        dataLogger?.clearLog()
        updateFileStats()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "SnoreChannel"
        val channel = NotificationChannel(channelId, "Snore Monitor", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Threshold Monitor Active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
        startDetection()
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startDetection() {
        if (isRunning) return
        isRunning = true
        addLog("Threshold Mode: Ready")
        addLog("Data Logger active: ${dataLogger?.getLogFilePath()}")
        
        thread {
            val policy = android.os.StrictMode.ThreadPolicy.Builder().permitAll().build()
            android.os.StrictMode.setThreadPolicy(policy)

            val sampleRate = 16000
            val bufferSizeSamples = 16000 // 1 second chunks
            val audioSource = MediaRecorder.AudioSource.MIC
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            
            val minBufSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            
            try {
                val record = AudioRecord(audioSource, sampleRate, channelConfig, audioFormat, minBufSize.coerceAtLeast(bufferSizeSamples * 2))

                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    addLog("MIC ERROR: Init Failed")
                    isRunning = false
                    return@thread
                }

                val audioBuffer = ShortArray(bufferSizeSamples)
                record.startRecording()
                addLog("Monitoring Sound Levels...")

                while (isRunning) {
                    val read = record.read(audioBuffer, 0, bufferSizeSamples)
                    if (read > 0) {
                        // 1. Calculate RMS Volume (0.0 to 1.0)
                        var sum = 0.0
                        for (i in 0 until read) sum += audioBuffer[i] * audioBuffer[i]
                        val rms = sqrt(sum / read).toFloat() / 32768.0f
                        val volPct = (rms * 100f).coerceIn(0f, 100f)
                        
                        _currentVolume.value = volPct

                        // 2. Voting Logic
                        val isAboveThreshold = rms >= VOLUME_THRESHOLD
                        votingHistory.add(isAboveThreshold)
                        if (votingHistory.size > VOTING_WINDOW_SIZE) votingHistory.removeFirst()

                        val votesCount = votingHistory.count { it }
                        
                        // 3. Trigger Logic
                        val currentTime = System.currentTimeMillis()
                        val isTriggered = votesCount >= VOTING_THRESHOLD && (currentTime - lastTriggerTime) > NUDGE_COOLDOWN_MS

                        if (isTriggered) {
                            _totalSnores.value += 1
                            addLog("TRIGGER: High Sound Detected ($votesCount/$VOTING_WINDOW_SIZE) -> ${stimulusType.uppercase()} $stimulusIntensity%")
                            triggerConfiguredStimulus()
                            lastTriggerTime = currentTime

                            dataLogger?.logSample(
                                rms = rms,
                                volumePercent = volPct,
                                isAboveThreshold = isAboveThreshold,
                                voteCount = votesCount,
                                triggered = true,
                                note = "SNORE TRIGGERED ($votesCount/$VOTING_WINDOW_SIZE votes, ${stimulusType.uppercase()} $stimulusIntensity%)"
                            )
                            votingHistory.clear() // Clear to avoid double trigger
                        } else {
                            val note = when {
                                currentTime - lastTriggerTime <= NUDGE_COOLDOWN_MS && votesCount >= VOTING_THRESHOLD -> "Cooldown Active"
                                isAboveThreshold -> "Sound Above Threshold"
                                else -> "Normal Audio"
                            }
                            dataLogger?.logSample(
                                rms = rms,
                                volumePercent = volPct,
                                isAboveThreshold = isAboveThreshold,
                                voteCount = votesCount,
                                triggered = false,
                                note = note
                            )
                        }

                        updateFileStats()
                        Log.d("ThresholdLog", "RMS: ${"%.4f".format(rms)} | Votes: $votesCount/3 | FileRecords: ${_fileRecordCount.value}")
                    }
                }
                record.stop()
                record.release()
            } catch (e: Exception) {
                addLog("MIC ERROR: ${e.message}")
            }
            isRunning = false
        }
    }

    fun updateApiToken(token: String) = bleManager?.setApiToken(token)

    fun updateStimulusConfig(type: String, intensity: Int) {
        stimulusType = type
        stimulusIntensity = intensity
        _stimulusType.value = type
        _stimulusIntensity.value = intensity
        getSharedPreferences("PavlokPrefs", MODE_PRIVATE).edit()
            .putString("stimulus_type", type)
            .putInt("stimulus_intensity", intensity)
            .apply()
        addLog("Stimulus Configured: ${type.uppercase()} @ ${intensity}%")
    }

    fun triggerConfiguredStimulus() {
        when (stimulusType.lowercase()) {
            "vibe", "vibrate" -> bleManager?.vibrate(stimulusIntensity)
            "zap" -> bleManager?.zap(stimulusIntensity)
            else -> bleManager?.beep(stimulusIntensity)
        }
    }

    fun triggerBeep(intensity: Int) = bleManager?.beep(intensity)
    fun triggerVibe(intensity: Int) = bleManager?.vibrate(intensity)
    fun triggerZap(intensity: Int) = bleManager?.zap(intensity)

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        bleManager?.close()
    }

    override fun onBind(intent: Intent?): IBinder = binder
}
