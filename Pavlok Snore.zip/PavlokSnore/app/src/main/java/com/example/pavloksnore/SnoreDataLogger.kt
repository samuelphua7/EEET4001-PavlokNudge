package com.example.pavloksnore

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SnoreDataLogger(private val context: Context) {

    private val fileName = "snore_detection_log.csv"
    val logFile: File
        get() {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            return File(dir, fileName)
        }

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    init {
        ensureHeader()
    }

    @Synchronized
    private fun ensureHeader() {
        val file = logFile
        if (!file.exists() || file.length() == 0L) {
            try {
                PrintWriter(FileWriter(file, true)).use { writer ->
                    writer.println("Timestamp,RMS_Volume,Volume_Percent,Is_Above_Threshold,Vote_Count,Snore_Triggered,Notes")
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @Synchronized
    fun logSample(
        rms: Float,
        volumePercent: Float,
        isAboveThreshold: Boolean,
        voteCount: Int,
        triggered: Boolean,
        note: String = ""
    ) {
        ensureHeader()
        val timestamp = dateFormat.format(Date())
        val formattedRms = String.format(Locale.US, "%.5f", rms)
        val formattedPct = String.format(Locale.US, "%.1f", volumePercent)
        val line = "$timestamp,$formattedRms,$formattedPct,$isAboveThreshold,$voteCount,$triggered,\"$note\""

        try {
            PrintWriter(FileWriter(logFile, true)).use { writer ->
                writer.println(line)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Synchronized
    fun clearLog() {
        try {
            val file = logFile
            if (file.exists()) {
                file.delete()
            }
            ensureHeader()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getLogFilePath(): String = logFile.absolutePath

    fun getRecordCount(): Int {
        val file = logFile
        if (!file.exists()) return 0
        return try {
            val lines = file.readLines()
            if (lines.isEmpty()) 0 else (lines.size - 1).coerceAtLeast(0)
        } catch (_: Exception) {
            0
        }
    }

    fun getFileSizeFormatted(): String {
        val file = logFile
        if (!file.exists()) return "0 B"
        val bytes = file.length()
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> String.format(Locale.US, "%.2f KB", bytes / 1024.0)
            else -> String.format(Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0))
        }
    }

    fun readRecentEntries(limit: Int = 50): List<CsvRecord> {
        val file = logFile
        if (!file.exists()) return emptyList()
        return try {
            val lines = file.readLines()
            if (lines.size <= 1) return emptyList()
            
            lines.drop(1).takeLast(limit).reversed().mapNotNull { line ->
                val parts = line.split(",")
                if (parts.size >= 6) {
                    val timestamp = parts[0]
                    val rms = parts[1]
                    val volPct = parts[2]
                    val isAbove = parts[3].toBoolean()
                    val voteCount = parts[4]
                    val triggered = parts[5].toBoolean()
                    val notes = if (parts.size > 6) parts[6].replace("\"", "") else ""
                    CsvRecord(timestamp, rms, volPct, isAbove, voteCount, triggered, notes)
                } else null
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun createShareIntent(): Intent? {
        val file = logFile
        if (!file.exists() || file.length() == 0L) return null

        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        return Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Pavlok Snore Detector Data Log")
            putExtra(Intent.EXTRA_TEXT, "Attached is the snore detection CSV data log file for validation.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}

data class CsvRecord(
    val timestamp: String,
    val rms: String,
    val volPercent: String,
    val isAboveThreshold: Boolean,
    val voteCount: String,
    val triggered: Boolean,
    val notes: String
)
