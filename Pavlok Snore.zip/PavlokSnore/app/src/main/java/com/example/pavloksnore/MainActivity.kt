package com.example.pavloksnore

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.pavloksnore.ui.theme.PavlokSnoreTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var isBound by mutableStateOf(false)
    private var snoreService: SnoreDetectorService? = null
    
    private val logs = mutableStateListOf<LogEntry>()
    private var bleState by mutableStateOf<PavlokBLEManager.BleState>(PavlokBLEManager.BleState.Disconnected)
    private var totalSnores by mutableStateOf(0)
    private var currentVolume by mutableStateOf(0f)
    private var currentTab by mutableStateOf(0)
    
    private var fileRecordCount by mutableStateOf(0)
    private var fileSizeText by mutableStateOf("0 B")
    private var logFilePath by mutableStateOf("")
    private val csvRecords = mutableStateListOf<CsvRecord>()

    private var savedToken by mutableStateOf("")
    private var stimulusType by mutableStateOf("beep")
    private var stimulusIntensity by mutableIntStateOf(80)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as SnoreDetectorService.ServiceBinder
            snoreService = binder.getService()
            isBound = true
            
            if (savedToken.isNotEmpty()) {
                snoreService?.updateApiToken(savedToken)
            }

            lifecycleScope.launch {
                snoreService?.logs?.collect { logs.clear(); logs.addAll(it) }
            }
            lifecycleScope.launch {
                snoreService?.bleStatus?.collect { bleState = it }
            }
            lifecycleScope.launch {
                snoreService?.totalSnores?.collect { totalSnores = it }
            }
            lifecycleScope.launch {
                snoreService?.currentVolume?.collect { currentVolume = it }
            }
            lifecycleScope.launch {
                snoreService?.fileRecordCount?.collect { 
                    fileRecordCount = it 
                    snoreService?.dataLogger?.let { logger ->
                        csvRecords.clear()
                        csvRecords.addAll(logger.readRecentEntries(50))
                    }
                }
            }
            lifecycleScope.launch {
                snoreService?.fileSizeText?.collect { fileSizeText = it }
            }
            lifecycleScope.launch {
                snoreService?.logFilePath?.collect { logFilePath = it }
            }
            lifecycleScope.launch {
                snoreService?.stimulusTypeFlow?.collect { stimulusType = it }
            }
            lifecycleScope.launch {
                snoreService?.stimulusIntensityFlow?.collect { stimulusIntensity = it }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            snoreService = null
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        if (perms.values.all { it }) startService()
        else Toast.makeText(this, "Permissions Required", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("PavlokPrefs", MODE_PRIVATE)
        savedToken = prefs.getString("api_token", "") ?: ""
        stimulusType = prefs.getString("stimulus_type", "beep") ?: "beep"
        stimulusIntensity = prefs.getInt("stimulus_intensity", 80)

        refreshLogData()

        setContent {
            PavlokSnoreTheme(darkTheme = true) {
                MainContent()
            }
        }
    }

    private fun updateStimulusConfig(type: String, intensity: Int) {
        stimulusType = type
        stimulusIntensity = intensity
        getSharedPreferences("PavlokPrefs", MODE_PRIVATE).edit()
            .putString("stimulus_type", type)
            .putInt("stimulus_intensity", intensity)
            .apply()
        snoreService?.updateStimulusConfig(type, intensity)
    }

    private fun refreshLogData() {
        val logger = snoreService?.dataLogger ?: SnoreDataLogger(this)
        fileRecordCount = logger.getRecordCount()
        fileSizeText = logger.getFileSizeFormatted()
        logFilePath = logger.getLogFilePath()
        csvRecords.clear()
        csvRecords.addAll(logger.readRecentEntries(50))
    }

    @Composable
    fun MainContent() {
        val pavlokYellow = Color(0xFFC0CA33)
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.Black) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Dashboard") },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = pavlokYellow, selectedTextColor = pavlokYellow)
                    )
                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = { Icon(Icons.Default.Lock, null) },
                        label = { Text("API Setup") },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = pavlokYellow, selectedTextColor = pavlokYellow)
                    )
                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Remote") },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = pavlokYellow, selectedTextColor = pavlokYellow)
                    )
                    NavigationBarItem(
                        selected = currentTab == 3,
                        onClick = { 
                            currentTab = 3 
                            refreshLogData()
                        },
                        icon = { Icon(Icons.AutoMirrored.Filled.List, null) },
                        label = { Text("Logs") },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = pavlokYellow, selectedTextColor = pavlokYellow)
                    )
                }
            },
            containerColor = Color(0xFF121212)
        ) { padding ->
            Column(modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                when (currentTab) {
                    0 -> DashboardTab(pavlokYellow)
                    1 -> ApiSetupTab(pavlokYellow)
                    2 -> RemoteTab(pavlokYellow)
                    3 -> LogsTab(pavlokYellow)
                }
            }
        }
    }

    @Composable
    fun DashboardTab(accent: Color) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
        ) {
            Text("PAVLOK SNORE", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold, color = accent)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            val isReady = bleState is PavlokBLEManager.BleState.Ready
            val statusColor = if (isReady) accent else Color(0xFFD32F2F)
            
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = statusColor.copy(alpha = 0.1f),
                border = androidx.compose.foundation.BorderStroke(1.dp, statusColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isReady) "CLOUD API LINK ACTIVE" else "API TOKEN MISSING", modifier = Modifier.padding(12.dp), color = statusColor, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Microphone Volume Visualizer
            Text("MICROPHONE INPUT SENSITIVITY", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { currentVolume / 100f },
                modifier = Modifier.fillMaxWidth().height(10.dp),
                color = if (currentVolume > 5) accent else Color.Gray,
                trackColor = Color.DarkGray,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(if (currentVolume > 5) "HEARING SOUND..." else "SILENT ROOM", style = MaterialTheme.typography.labelSmall, color = if (currentVolume > 5) accent else Color.Gray)

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SNORES DETECTED", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                    Text("$totalSnores", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Snore Stimulus Response Configuration Card
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("RESPONSE ON SNORE DETECTED", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("beep" to "BEEP", "vibe" to "VIBRATE", "zap" to "ZAP").forEach { (typeKey, label) ->
                            FilterChip(
                                selected = stimulusType.lowercase() == typeKey,
                                onClick = { updateStimulusConfig(typeKey, stimulusIntensity) },
                                label = { Text(label, fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (typeKey == "zap") Color(0xFFD32F2F) else accent,
                                    selectedLabelColor = Color.Black,
                                    containerColor = Color(0xFF2C2C2C),
                                    labelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("INTENSITY", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Text("${stimulusIntensity}%", color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Slider(
                        value = stimulusIntensity.toFloat(),
                        onValueChange = { updateStimulusConfig(stimulusType, it.toInt()) },
                        valueRange = 10f..100f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = if (stimulusType == "zap") Color.Red else accent,
                            activeTrackColor = if (stimulusType == "zap") Color.Red else accent
                        )
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        OutlinedButton(
                            onClick = {
                                snoreService?.triggerConfiguredStimulus()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = accent)
                        ) {
                            Text("TEST RESPONSE (${stimulusType.uppercase()})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // File logging summary status
            Surface(
                color = Color(0xFF1E1E1E),
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("DATA LOG FILE:", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("$fileRecordCount records ($fileSizeText)", fontSize = 12.sp, color = accent, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { if (isBound) stopService() else checkPerms() },
                colors = ButtonDefaults.buttonColors(containerColor = if (isBound) Color.DarkGray else accent),
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = MaterialTheme.shapes.large
            ) {
                Text(if (isBound) "STOP MONITORING" else "START MONITORING", color = if (isBound) Color.White else Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    fun ApiSetupTab(accent: Color) {
        var tokenInput by remember { mutableStateOf(savedToken) }
        Column(modifier = Modifier.fillMaxSize()) {
            Text("CLOUD API SETUP", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Get your token from pavlok.com/developers", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
            Spacer(modifier = Modifier.height(24.dp))
            TextField(
                value = tokenInput,
                onValueChange = { tokenInput = it },
                label = { Text("Bearer Token") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    saveToken(tokenInput)
                    Toast.makeText(this@MainActivity, "Token Saved", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = accent)
            ) {
                Text("SAVE & CONNECT BRIDGE", color = Color.Black)
            }
        }
    }

    @Composable
    fun RemoteTab(accent: Color) {
        Column(modifier = Modifier.fillMaxSize()) {
            Text("CLOUD REMOTE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(24.dp))
            RemoteSlider("BEEP", Icons.Default.Notifications, accent) { snoreService?.triggerBeep(it) }
            RemoteSlider("VIBRATE", Icons.Default.Info, accent) { snoreService?.triggerVibe(it) }
            RemoteSlider("ZAP", Icons.Default.Warning, Color.Red) { snoreService?.triggerZap(it) }
        }
    }

    @Composable
    fun RemoteSlider(label: String, icon: ImageVector, color: Color, onTrigger: (Int) -> Unit) {
        var intensity by remember { mutableStateOf(50f) }
        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, tint = color)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(label, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.weight(1f))
                    Text("${intensity.toInt()}%", color = color, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = intensity,
                    onValueChange = { intensity = it },
                    valueRange = 10f..100f,
                    steps = 8,
                    colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color)
                )
                Button(
                    onClick = { onTrigger(intensity.toInt()) },
                    modifier = Modifier.align(Alignment.End),
                    colors = ButtonDefaults.buttonColors(containerColor = color.copy(alpha = 0.2f), contentColor = color)
                ) {
                    Text("TRIGGER CLOUD")
                }
            }
        }
    }

    @Composable
    fun LogsTab(accent: Color) {
        var selectedLogType by remember { mutableIntStateOf(0) }

        Column(modifier = Modifier.fillMaxSize()) {
            Text("VALIDATION & LOGS", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedLogType == 0,
                    onClick = { selectedLogType = 0 },
                    label = { Text("CSV Data File ($fileRecordCount)") },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = accent,
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0xFF1E1E1E),
                        labelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedLogType == 1,
                    onClick = { selectedLogType = 1 },
                    label = { Text("System Logs (${logs.size})") },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = accent,
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0xFF1E1E1E),
                        labelColor = Color.White
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedLogType == 0) {
                DataFileSection(accent)
            } else {
                SystemLogsSection()
            }
        }
    }

    @Composable
    fun DataFileSection(accent: Color) {
        val logger = remember(isBound) { snoreService?.dataLogger ?: SnoreDataLogger(this) }
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = accent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("STORED CSV DATA LOG", fontWeight = FontWeight.Bold, color = Color.White)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Path: ${logFilePath.ifEmpty { logger.getLogFilePath() }}", fontSize = 11.sp, color = Color.Gray)
                
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Records: $fileRecordCount", color = Color.LightGray, fontSize = 13.sp)
                    Text("Size: $fileSizeText", color = Color.LightGray, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val shareIntent = logger.createShareIntent()
                            if (shareIntent != null) {
                                startActivity(Intent.createChooser(shareIntent, "Share Snore Data Log"))
                            } else {
                                Toast.makeText(this@MainActivity, "No CSV data file to share", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export CSV", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            if (snoreService != null) {
                                snoreService?.clearDataLog()
                            } else {
                                logger.clearLog()
                            }
                            refreshLogData()
                            Toast.makeText(this@MainActivity, "Data log cleared", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear File", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("RECENT DATA ENTRIES", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))

        if (csvRecords.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No logged audio data yet. Start monitoring to log data.", color = Color.Gray, fontSize = 13.sp)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(csvRecords) { record ->
                    CsvRecordRow(record, accent)
                }
            }
        }
    }

    @Composable
    fun CsvRecordRow(record: CsvRecord, accent: Color) {
        val bgColor = if (record.triggered) Color(0xFF3E2723) else Color(0xFF1E1E1E)
        val borderColor = if (record.triggered) accent else Color.Transparent

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = bgColor),
            border = if (record.triggered) androidx.compose.foundation.BorderStroke(1.dp, borderColor) else null
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(record.timestamp, color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    if (record.triggered) {
                        Surface(
                            color = accent,
                            shape = MaterialTheme.shapes.extraSmall
                        ) {
                            Text(
                                "TRIGGERED",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else {
                        Text(
                            if (record.isAboveThreshold) "ABOVE THRESHOLD" else "NORMAL",
                            color = if (record.isAboveThreshold) Color(0xFFFFB74D) else Color.DarkGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("RMS: ${record.rms} (${record.volPercent}%)", color = Color.White, fontSize = 12.sp)
                    Text("Votes: ${record.voteCount}", color = Color.LightGray, fontSize = 12.sp)
                }

                if (record.notes.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Note: ${record.notes}", color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }

    @Composable
    fun SystemLogsSection() {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(logs) { log ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Text(log.timestamp, color = Color.Gray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(log.message, color = Color.LightGray, fontSize = 14.sp)
                }
            }
        }
    }

    private fun saveToken(token: String) {
        savedToken = token
        getSharedPreferences("PavlokPrefs", MODE_PRIVATE).edit().putString("api_token", token).apply()
        snoreService?.updateApiToken(token)
    }

    private fun checkPerms() {
        val missing = listOf(Manifest.permission.RECORD_AUDIO).filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startService()
        else permLauncher.launch(missing.toTypedArray())
    }

    private fun startService() {
        val intent = Intent(this, SnoreDetectorService::class.java)
        startForegroundService(intent)
        bindService(intent, connection, BIND_AUTO_CREATE)
    }

    private fun stopService() {
        stopService(Intent(this, SnoreDetectorService::class.java))
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
        totalSnores = 0
        currentVolume = 0f
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, SnoreDetectorService::class.java), connection, BIND_AUTO_CREATE)
        refreshLogData()
    }

    override fun onStop() {
        super.onStop()
        if (isBound) unbindService(connection)
    }
}
